// This file is no longer needed when using standalone components.
// You can delete this file or leave it empty.